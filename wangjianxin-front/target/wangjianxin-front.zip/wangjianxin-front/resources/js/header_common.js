/**
 * Created by wangjianxin on 2016/11/7.
 */
function a(){location.href='/'}
function b(){location.href='/about.html'}
function c(){location.href='/star.html'}
function d(){location.href='/login.html'}