function starDetail(id){
    location.href="/star/derail.html?id="+id
}